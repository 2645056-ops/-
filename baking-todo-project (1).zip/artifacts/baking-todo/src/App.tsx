import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { Check, CheckCheck, ClipboardList, Plus, Trash2 } from 'lucide-react';

type Task = { id: string; title: string; completed: boolean; createdAt: number };
type Filter = 'all' | 'active' | 'completed';
const STORAGE_KEY = 'baking-notebook-tasks-v1';
const STARTER_TASK_KEY = 'baking-notebook-starter-added-v1';
const STARTER_TASK_TITLE = '크루아상 반죽 만들기';
const BAKING_TASKS_KEY = 'baking-notebook-practical-tasks-added-v1';
const BAKING_TASK_TITLES = [
  '마들렌 반죽 계량하기',
  '생크림 70% 휘핑하기',
  '딸기 무스 케이크 만들기',
  '실습 도구 세척 및 정리하기',
];
const FILTERS: { id: Filter; label: string }[] = [
  { id: 'all', label: '전체 보기' },
  { id: 'active', label: '진행 중' },
  { id: 'completed', label: '완료' },
];

function readTasks(): Task[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]');
    if (!Array.isArray(value)) return [];
    const tasks = value.filter(
      (task): task is Task =>
        typeof task?.id === 'string' &&
        typeof task?.title === 'string' &&
        typeof task?.completed === 'boolean' &&
        typeof task?.createdAt === 'number',
    );
    if (localStorage.getItem(STARTER_TASK_KEY) !== 'true') {
      localStorage.setItem(STARTER_TASK_KEY, 'true');
      if (!tasks.some((task) => task.title === STARTER_TASK_TITLE)) {
        const createdAt = Date.now();
        tasks.unshift({
          id: `starter-${createdAt}`,
          title: STARTER_TASK_TITLE,
          completed: false,
          createdAt,
        });
      }
    }

    if (localStorage.getItem(BAKING_TASKS_KEY) !== 'true') {
      localStorage.setItem(BAKING_TASKS_KEY, 'true');
      const existingTitles = new Set(tasks.map((task) => task.title));
      const createdAt = Date.now();
      const newTasks = BAKING_TASK_TITLES.filter(
        (title) => !existingTitles.has(title),
      ).map((title, index) => ({
        id: `practical-${createdAt}-${index}`,
        title,
        completed: false,
        createdAt: createdAt + index,
      }));
      return [...newTasks, ...tasks];
    }

    return tasks;
  } catch {
    return [];
  }
}

function Home() {
  const [tasks, setTasks] = useState<Task[]>(readTasks);
  const [filter, setFilter] = useState<Filter>('all');
  const [draft, setDraft] = useState('');
  const [notice, setNotice] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const remaining = tasks.filter((task) => !task.completed).length;
  const completed = tasks.length - remaining;
  const visibleTasks = useMemo(
    () =>
      tasks.filter((task) => {
        if (filter === 'active') return !task.completed;
        if (filter === 'completed') return task.completed;
        return true;
      }),
    [filter, tasks],
  );

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch {
      setNotice('저장 공간이 부족해 목록을 저장하지 못했어요.');
    }
  }, [tasks]);

  function addTask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const title = draft.trim();
    if (!title) {
      setNotice('할 일을 먼저 적어 주세요.');
      inputRef.current?.focus();
      return;
    }
    setTasks((current) => [
      { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, title, completed: false, createdAt: Date.now() },
      ...current,
    ]);
    setDraft('');
    setNotice('새 할 일을 목록에 담았어요.');
    inputRef.current?.focus();
  }

  function toggleTask(id: string) {
    setTasks((current) =>
      current.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)),
    );
    setNotice('할 일 상태를 바꿨어요.');
  }

  function deleteTask(id: string) {
    setTasks((current) => current.filter((task) => task.id !== id));
    setNotice('할 일을 목록에서 지웠어요.');
  }

  const today = new Intl.DateTimeFormat('ko-KR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    weekday: 'long',
  }).format(new Date());

  return (
    <main className="page-shell">
      <div className="paper-grain" aria-hidden="true" />
      <div className="notebook">
        <header className="topline">
          <div className="brand-mark" aria-hidden="true"><span className="brand-dot" /><span className="brand-dot" /><span className="brand-dot" /></div>
          <span className="brand-name">작은 반죽 노트</span>
          <span className="topline-rule" />
          <span className="date-label" data-testid="text-today-date">{today}</span>
        </header>

        <section className="intro" aria-labelledby="page-title">
          <div className="intro-copy">
            <p className="eyebrow"><span className="eyebrow-line" /> 오늘의 기록</p>
            <h1 id="page-title">나의 베이킹<br className="mobile-break" /> 할 일 목록<span className="title-period">.</span></h1>
            <p className="intro-note">차근차근 하나씩, 오늘의 반죽을 시작해요.</p>
          </div>
          <div className="flourish" aria-hidden="true">
            <div className="flourish-sun" />
            <div className="flourish-bowl"><span /></div>
            <div className="flourish-spark spark-one" />
            <div className="flourish-spark spark-two" />
            <div className="flourish-line" />
          </div>
        </section>

        <section className="summary" aria-label="할 일 요약">
          <div className="summary-heading">
            <span className="summary-kicker">오늘의 체크</span>
            <span className="summary-caption">{tasks.length === 0 ? '첫 번째 할 일을 적어 보세요' : '천천히, 내 페이스대로'}</span>
          </div>
          <div className="summary-stats">
            <div className="stat-block">
              <span className="stat-number" data-testid="text-total-count">{tasks.length.toString().padStart(2, '0')}</span>
              <span className="stat-label">전체</span>
            </div>
            <span className="stat-divider" />
            <div className="stat-block">
              <span className="stat-number stat-blue" data-testid="text-remaining-count">{remaining.toString().padStart(2, '0')}</span>
              <span className="stat-label">남은 할 일</span>
            </div>
            <div className="progress-area" aria-label={`완료 ${completed}개, 전체 ${tasks.length}개`}>
              <div className="progress-track"><span style={{ width: `${tasks.length ? (completed / tasks.length) * 100 : 0}%` }} /></div>
              <span className="progress-copy">{tasks.length ? `${completed} / ${tasks.length} 완료` : '아직 시작 전'}</span>
            </div>
          </div>
        </section>

        <section className="todo-panel" aria-labelledby="list-heading">
          <div className="list-top">
            <div>
              <p className="section-index">01 <span>—</span> 오늘의 목록</p>
              <h2 id="list-heading">오늘 할 일</h2>
            </div>
            <div className="filter-tabs" role="tablist" aria-label="할 일 필터">
              {FILTERS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={filter === item.id}
                  className={`filter-tab ${filter === item.id ? 'is-selected' : ''}`}
                  onClick={() => setFilter(item.id)}
                  data-testid={`filter-${item.id}`}
                >
                  {item.label}
                  {item.id === 'all' && <span className="filter-count">{tasks.length}</span>}
                </button>
              ))}
            </div>
          </div>

          <form className="add-form" onSubmit={addTask} data-testid="form-add-task">
            <label className="sr-only" htmlFor="task-input">새 할 일</label>
            <span className="input-plus" aria-hidden="true"><Plus size={18} strokeWidth={1.8} /></span>
            <input
              ref={inputRef}
              id="task-input"
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="예: 크루아상 반죽 접기"
              maxLength={100}
              autoComplete="off"
              data-testid="input-new-task"
            />
            <span className="input-hint">입력 후 엔터</span>
            <button className="add-button" type="submit" aria-label="할 일 추가" data-testid="button-add-task">
              <Plus size={18} strokeWidth={2} /><span>추가</span>
            </button>
          </form>
          <p className="sr-only" role="status" aria-live="polite" data-testid="status-feedback">{notice}</p>

          <div className="task-list" aria-live="polite" data-testid="list-tasks">
            {visibleTasks.length > 0 ? (
              visibleTasks.map((task, index) => (
                <article className={`task-row ${task.completed ? 'is-complete' : ''}`} key={task.id} data-testid={`task-item-${task.id}`}>
                  <button
                    type="button"
                    className={`task-check ${task.completed ? 'checked' : ''}`}
                    onClick={() => toggleTask(task.id)}
                    aria-label={`${task.title} ${task.completed ? '완료 취소' : '완료 표시'}`}
                    aria-pressed={task.completed}
                    data-testid={`checkbox-task-${task.id}`}
                  >
                    {task.completed && <Check size={15} strokeWidth={2.4} />}
                  </button>
                  <span className="task-number">{String(index + 1).padStart(2, '0')}</span>
                  <span className="task-title" data-testid={`text-task-title-${task.id}`}>{task.title}</span>
                  {task.completed && <span className="done-label" data-testid={`status-task-${task.id}`}>완료</span>}
                  <button
                    type="button"
                    className="delete-button"
                    onClick={() => deleteTask(task.id)}
                    aria-label={`${task.title} 삭제`}
                    data-testid={`button-delete-task-${task.id}`}
                  >
                    <Trash2 size={16} strokeWidth={1.7} />
                  </button>
                </article>
              ))
            ) : (
              <div className="empty-state" data-testid="empty-state">
                <div className="empty-icon" aria-hidden="true">
                  {filter === 'completed' ? <CheckCheck size={23} strokeWidth={1.4} /> : <ClipboardList size={23} strokeWidth={1.4} />}
                </div>
                <p className="empty-title">
                  {filter === 'all' ? '아직 적어 둔 할 일이 없어요' : filter === 'active' ? '진행 중인 할 일이 없어요' : '아직 완료한 할 일이 없어요'}
                </p>
                <p className="empty-description">
                  {filter === 'all' ? '오늘 만들고 싶은 것부터 하나씩 적어 보세요.' : filter === 'active' ? '모든 할 일을 마쳤어요. 참 잘했어요.' : '할 일을 완료하면 이곳에 모아 둘게요.'}
                </p>
                {filter === 'all' && <button type="button" className="empty-cta" onClick={() => inputRef.current?.focus()} data-testid="button-empty-focus">첫 할 일 적기 <span>↗</span></button>}
              </div>
            )}
          </div>
          <footer className="list-footer">
            <span className="footer-stitch" />
            <span>작은 진전도 충분히 멋져요</span>
            <span className="footer-stitch" />
          </footer>
        </section>
        <footer className="page-footer"><span>매일 조금씩, 즐겁게 굽기</span><span className="footer-mark">— 01 —</span></footer>
      </div>
    </main>
  );
}

export default Home;
